package com.streetclash.game;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
  WebView w;
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    if (Build.VERSION.SDK_INT >= 28) {
      WindowManager.LayoutParams p = getWindow().getAttributes();
      p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      getWindow().setAttributes(p);
    }
    w = new WebView(this);
    setContentView(w);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setAllowFileAccess(true);
    s.setSupportZoom(false);
    s.setBuiltInZoomControls(false);
    w.setLayerType(View.LAYER_TYPE_HARDWARE, null);
    w.setOverScrollMode(View.OVER_SCROLL_NEVER);
    w.setBackgroundColor(0xFF0A0520);
    w.setWebViewClient(new WebViewClient());
    w.setWebChromeClient(new WebChromeClient());
    w.loadUrl("file:///android_asset/index.html");
  }
  void immersive() {
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
  }
  @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }
  @Override protected void onPause() { super.onPause(); w.onPause(); }
  @Override protected void onResume() { super.onResume(); w.onResume(); immersive(); }
  @Override protected void onDestroy() { w.destroy(); super.onDestroy(); }
}
